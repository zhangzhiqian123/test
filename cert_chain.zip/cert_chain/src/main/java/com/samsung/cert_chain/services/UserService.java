package com.samsung.cert_chain.services;

import com.samsung.cert_chain.model.AppUser;
import com.samsung.cert_chain.model.ResultModel;

import java.util.List;


public interface UserService {
    List<AppUser> getAllUser(Integer page, Integer rows,Integer org_id);
    ResultModel SaveUser(AppUser course);
    ResultModel deleteUser(int userId);
}
