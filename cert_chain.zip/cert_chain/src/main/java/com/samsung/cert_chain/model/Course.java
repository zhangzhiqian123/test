package com.samsung.cert_chain.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Date;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Course {
    private Integer courseId;

    private String courseName;

    private String courseImage;

    private String coursePeriod;

    private Integer courseAllstudent;

    private String courseTeacher;

    private Date courseStarttime;

    private Date courseEndtime;

    private String courseDetail;

    private Integer courseAuthority;

    private Integer orgId;

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName == null ? null : courseName.trim();
    }

    public String getCourseImage() {
        return courseImage;
    }

    public void setCourseImage(String courseImage) {
        this.courseImage = courseImage == null ? null : courseImage.trim();
    }

    public String getCoursePeriod() {
        return coursePeriod;
    }

    public void setCoursePeriod(String coursePeriod) {
        this.coursePeriod = coursePeriod == null ? null : coursePeriod.trim();
    }

    public Integer getCourseAllstudent() {
        return courseAllstudent;
    }

    public void setCourseAllstudent(Integer courseAllstudent) {
        this.courseAllstudent = courseAllstudent;
    }

    public String getCourseTeacher() {
        return courseTeacher;
    }

    public void setCourseTeacher(String courseTeacher) {
        this.courseTeacher = courseTeacher == null ? null : courseTeacher.trim();
    }

    public Date getCourseStarttime() {
        return courseStarttime;
    }

    public void setCourseStarttime(Date courseStarttime) {
        this.courseStarttime = courseStarttime;
    }

    public Date getCourseEndtime() {
        return courseEndtime;
    }

    public void setCourseEndtime(Date courseEndtime) {
        this.courseEndtime = courseEndtime;
    }

    public String getCourseDetail() {
        return courseDetail;
    }

    public void setCourseDetail(String courseDetail) {
        this.courseDetail = courseDetail == null ? null : courseDetail.trim();
    }

    public Integer getCourseAuthority() {
        return courseAuthority;
    }

    public void setCourseAuthority(Integer courseAuthority) {
        this.courseAuthority = courseAuthority;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }
}