package com.samsung.cert_chain.services;

import com.samsung.cert_chain.model.AppUser;
import com.samsung.cert_chain.model.Orgnation;

import java.util.List;

public interface Loginservice {

    AppUser selectUserById(int userId);

    Orgnation selectByOrgName(String orgname);
    AppUser selectByUserName(String username);
    Orgnation getOrg(String orgname);
}
