package com.samsung.cert_chain.mapper;

import com.samsung.cert_chain.model.Course;
import com.samsung.cert_chain.model.CourseExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CourseMapper {
    long countByExample(CourseExample example);

    int deleteByExample(CourseExample example);

    int insert(Course record);

    int insertSelective(Course record);

    List<Course> selectByExample(CourseExample example);

    int updateByExampleSelective(@Param("record") Course record, @Param("example") CourseExample example);

    int updateByExample(@Param("record") Course record, @Param("example") CourseExample example);

    List<Course> getAllByCourse(Integer org_id);
    List<Course> getAppCourse(Integer org_id);
    List<Course> getDetailCourse(Integer course_id);
}