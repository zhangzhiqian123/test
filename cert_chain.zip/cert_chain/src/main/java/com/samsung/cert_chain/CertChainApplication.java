package com.samsung.cert_chain;

//import org.fcw.Fcw;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@MapperScan("com.samsung.cert_chain.mapper")
@ComponentScan(basePackages = {"com.samsung.cert_chain.*"})

public class CertChainApplication {

    public static void main(String[] args) {
        SpringApplication.run(CertChainApplication.class, args);
//        Fcw.registerEnrollUser("testUser130");
//        int i = 1;
//        String[] arguments = new String[]{"138" + i, "a" + i, "b" + i, "c" + i};
//        while(true) {
//            if (i < 10)
//            Fcw.invokeChaincode("testUser130", "createCer", arguments).whenComplete((txId, e) -> {
//                if (null != txId) {
//                    System.out.println("Invoke success with txId: " + txId);
//                    Fcw.queryTransaction(txId);
//                }
//
//            });
//            ++i;
//        }
    }

}

