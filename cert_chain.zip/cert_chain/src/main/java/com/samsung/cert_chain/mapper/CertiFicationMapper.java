package com.samsung.cert_chain.mapper;

import com.samsung.cert_chain.model.CertiFication;
import com.samsung.cert_chain.model.CertiFicationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CertiFicationMapper {
    long countByExample(CertiFicationExample example);

    int deleteByExample(CertiFicationExample example);

    int deleteByPrimaryKey(Integer certId);

    int insert(CertiFication record);

    int insertSelective(CertiFication record);

    List<CertiFication> selectByExample(CertiFicationExample example);

    CertiFication selectByPrimaryKey(Integer certId);

    int updateByExampleSelective(@Param("record") CertiFication record, @Param("example") CertiFicationExample example);

    int updateByExample(@Param("record") CertiFication record, @Param("example") CertiFicationExample example);

    int updateByPrimaryKeySelective(CertiFication record);

    int updateByPrimaryKey(CertiFication record);
    List<CertiFication> getAllByCert(Integer org_id);
}