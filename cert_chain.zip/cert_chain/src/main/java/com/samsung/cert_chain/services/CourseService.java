package com.samsung.cert_chain.services;

import com.samsung.cert_chain.model.Course;
import com.samsung.cert_chain.model.ResultModel;

import java.util.List;

public interface CourseService {
    List<Course> getAllCourse(Integer page, Integer rows,Integer org_id);
  // List<Course> getAllCourse(Integer org_id);
    ResultModel save(Course course);
    List<Course> getAppCourse(Integer id);
    List<Course> getDetailCourse(Integer course_id);
}
