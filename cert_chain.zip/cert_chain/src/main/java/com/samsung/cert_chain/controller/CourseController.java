package com.samsung.cert_chain.controller;

import com.github.pagehelper.PageHelper;
import com.samsung.cert_chain.config.Constants;
import com.samsung.cert_chain.config.ResultStatus;
import com.samsung.cert_chain.model.Course;
import com.samsung.cert_chain.model.ResultModel;
import com.samsung.cert_chain.services.CourseService;
import com.samsung.cert_chain.utils.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/api")
@CrossOrigin
public class CourseController {
    @Autowired
    private CourseService courseService;
//,produces="application/json;application/x-www-form-urlencoded;charset=utf-8"
    @RequestMapping(value = "/course/getallcourse",method = RequestMethod.POST)

    public ResponseEntity<ResultModel> getAllCourse(Integer page,Integer rows,Integer org_id){
        System.out.println(page);
        System.out.println(rows);
        System.out.println(org_id);
        if(null != page && null != rows && null != org_id) {
            List<Course> courseList = this.courseService.getAllCourse(page, rows, org_id);

            return new ResponseEntity<ResultModel>(ResultModel.ok(courseList), HttpStatus.OK);
        } {
            return  new ResponseEntity<>(ResultModel.error(ResultStatus.GOOD_NOT_FOUND),HttpStatus.NOT_FOUND);
        }
    }

    /*@RequestMapping(value = "course/AddCourse",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> AddCourse(Integer org_id, String course_name, String course_detail,
                                                  String course_period, String course_teacher, MultipartFile imageFile){

        if (null == imageFile) {
            return new ResponseEntity<ResultModel>(ResultModel.error(ResultStatus.IMAGE_NOT_EMPTY), HttpStatus.BAD_REQUEST);
        }

//        String path = request.getServletContext().getRealPath(Constants.IAMGE_SAVE_PATH);
        String fileName = "";
        try {
            fileName = FileUtil.upload(imageFile, Constants.IMAGE_SAVE_PATH);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Course course = new Course();
        course.setOrgId(org_id);
       // course.setCourseId(1000);
        course.setCourseName(course_name);
        course.setCourseDetail(course_detail);
        course.setCoursePeriod(course_period);
        course.setCourseTeacher(course_teacher);
        course.setCourseImage(fileName);
        ResultModel resultModel = this.courseService.save(course);
        if (resultModel.getCode() == -1005 || resultModel.getCode()==-1004 ){
            return new ResponseEntity<ResultModel>(resultModel,HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<ResultModel>(ResultModel.ok(),HttpStatus.OK);
    }*/
    @RequestMapping(value = "course/AddCourse",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> AddCourse(Integer org_id, String course_name, String course_detail,
                                                 String course_period, String course_teacher){

        System.out.println(org_id);
        System.out.println(course_name);
        System.out.println(course_detail);
        System.out.println(course_period);
        System.out.println(course_teacher);
        Course course = new Course();
        course.setOrgId(org_id);
        // course.setCourseId(1000);
        course.setCourseName(course_name);
        course.setCourseDetail(course_detail);
        course.setCoursePeriod(course_period);
        course.setCourseTeacher(course_teacher);
        ResultModel resultModel = this.courseService.save(course);

        return new ResponseEntity<ResultModel>(ResultModel.ok(),HttpStatus.OK);
    }
    @RequestMapping(value = "/app/course/getallCourse",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> getappAllCourse(Integer org_id){
        Map<String,Object> map = new HashMap<>();
        Map<String,Object> map1 = new HashMap<>();
        List  courselist = this.courseService.getAppCourse(org_id);
        map.put("id",org_id);
        map.put("child",courselist);
        map.put("orgname1","易生生教育");
        map1.put("org1",map);
        return  new ResponseEntity<>(ResultModel.ok(map1),HttpStatus.OK);
    }
    @RequestMapping(value = "/app/course/getdetailCourse",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> getappDetailCourse(Integer course_id){
        List  courselist = this.courseService.getDetailCourse(course_id);
        return  new ResponseEntity<>(ResultModel.ok(courselist),HttpStatus.OK);
    }
}
