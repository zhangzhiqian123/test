package com.samsung.cert_chain.controller;

import com.samsung.cert_chain.config.Constants;
import com.samsung.cert_chain.config.ResultStatus;
import com.samsung.cert_chain.model.Orgnation;
import com.samsung.cert_chain.model.ResultModel;
import com.samsung.cert_chain.services.Registerservice;
import com.samsung.cert_chain.utils.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class RegisterController {

    @Autowired
    private Registerservice registerservice;

    private Orgnation orgnation;
    @RequestMapping(value = "/register",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> Reisterorg(String phone, String mail,String Org_name,String password, MultipartFile imageFile){
        System.out.println(Org_name);
        System.out.println(phone);
        System.out.println(mail);
        System.out.println(password);
        if (null == imageFile){
            return new ResponseEntity<>(ResultModel.error(ResultStatus.IMAGE_NOT_EMPTY), HttpStatus.BAD_REQUEST);
        }
        String filName =  "";
        try {
            filName = FileUtil.upload(imageFile, Constants.IMAGE_SAVE_PATH);
        }catch (Exception e){
            e.printStackTrace();
        }
        orgnation = new Orgnation();
        orgnation.setOrgName(Org_name);
        orgnation.setOrgPhone(phone);
        orgnation.setOrgMail(mail);
        orgnation.setOrgPassword(password);
        orgnation.setOrgLicense(filName);
        ResultModel resultModel = this.registerservice.save(orgnation);
        if (resultModel.getCode() == -1005 || resultModel.getCode()==-1004 ){
            return new ResponseEntity<ResultModel>(resultModel,HttpStatus.BAD_REQUEST);
        }else {
            return new ResponseEntity<>(resultModel.ok(), HttpStatus.CREATED);
        }
    }
    @RequestMapping(value = "/test",method = RequestMethod.GET)
    public  String test(){
        return "sasas";
    }
}
