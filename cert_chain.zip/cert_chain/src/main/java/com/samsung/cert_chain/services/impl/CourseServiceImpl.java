package com.samsung.cert_chain.services.impl;

import com.github.pagehelper.PageHelper;
import com.samsung.cert_chain.config.Constants;
import com.samsung.cert_chain.config.ResultStatus;
import com.samsung.cert_chain.mapper.CourseMapper;
import com.samsung.cert_chain.model.Course;
import com.samsung.cert_chain.model.CourseExample;
import com.samsung.cert_chain.model.ResultModel;
import com.samsung.cert_chain.services.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CourseServiceImpl implements CourseService {
    @Autowired
    private CourseMapper courseMapper;
    @Override
    public List<Course> getAllCourse(Integer page, Integer rows,Integer org_id) {
        if (null != page && null != rows) {
            PageHelper.startPage(page, rows);
        }
        CourseExample courseExample = new CourseExample();
        CourseExample.Criteria  criteria = courseExample.createCriteria();
        List<Course> list = this.courseMapper.getAllByCourse(org_id);
        for (Course c:list){
            c.setCourseImage(Constants.IMAGE_PREFIX_URL + c.getCourseImage());
        }
        return list;
    }

    @Override
    public ResultModel save(Course course) {
        if (null == course.getCourseName() || null == course.getCourseDetail()){
            return ResultModel.error(ResultStatus.DATA_NOT_NULL);
        }
        this.courseMapper.insert(course);
        return ResultModel.ok();
    }

    @Override
    public List<Course> getAppCourse(Integer id) {
        CourseExample courseExample = new CourseExample();
        CourseExample.Criteria criteria = courseExample.createCriteria();
        List<Course> list = this.courseMapper.getAppCourse(id);
        for (Course c:list){
            c.setCourseImage(Constants.IMAGE_PREFIX_URL + c.getCourseImage());
        }
        return list;
    }

    @Override
    public List<Course> getDetailCourse(Integer course_id) {
        CourseExample courseExample = new CourseExample();
        CourseExample.Criteria criteria = courseExample.createCriteria();
        List<Course> list = this.courseMapper.getDetailCourse(course_id);
        for (Course c:list){
            c.setCourseImage(Constants.IMAGE_PREFIX_URL + c.getCourseImage());
        }
        return list;
    }
}
