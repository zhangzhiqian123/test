package com.samsung.cert_chain.controller;


import com.samsung.cert_chain.config.Constants;
import com.samsung.cert_chain.config.ResultStatus;
import com.samsung.cert_chain.model.CertiFication;
import com.samsung.cert_chain.model.ResultModel;
import com.samsung.cert_chain.services.CertService;
import com.samsung.cert_chain.utils.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class CertController {
    @Autowired
    private CertService certService;

    private CertiFication certiFication;

    @RequestMapping(value = "/cert/getallcert",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> getAllCourse(Integer page,Integer rows,Integer org_id){
        if(null != page || null != rows || null != org_id) {

            List<CertiFication> certiFicationList = this.certService.getAllCert(page, rows, org_id);

            return new ResponseEntity<ResultModel>(ResultModel.ok(certiFicationList), HttpStatus.OK);
        }else {
            return  new ResponseEntity<>(ResultModel.error(ResultStatus.GOOD_NOT_FOUND),HttpStatus.NOT_FOUND);
        }
    }


    @RequestMapping(value = "/cert/addcert",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> AddCert(Integer org_id, String certname,  MultipartFile imageFile){
        if (null == imageFile){
            return new ResponseEntity<>(ResultModel.error(ResultStatus.IMAGE_NOT_EMPTY), HttpStatus.BAD_REQUEST);
        }
        String filName =  "";
        try {
            filName = FileUtil.upload(imageFile, Constants.IMAGE_SAVE_PATH);
        }catch (Exception e){
            e.printStackTrace();
        }
        certiFication = new CertiFication();
        certiFication.setOrgId(org_id);
        certiFication.setCertName(certname);
        certiFication.setCertImage(filName);
        ResultModel resultModel = this.certService.save(certiFication);
        return new ResponseEntity<>(ResultModel.ok(),HttpStatus.CREATED);
    }
    @RequestMapping(value = "/app/Cert/getallCert",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> getappAllCert(Integer user_id){

        List  certlist = this.certService.getAppCert(user_id);

        return  new ResponseEntity<>(ResultModel.ok(certlist),HttpStatus.OK);
    }
}
