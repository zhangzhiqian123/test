package com.samsung.cert_chain.services.impl;

import com.samsung.cert_chain.config.ResultStatus;
import com.samsung.cert_chain.mapper.OrgnationMapper;
import com.samsung.cert_chain.model.Orgnation;
import com.samsung.cert_chain.model.ResultModel;
import com.samsung.cert_chain.services.Registerservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegisterServiceImpl implements Registerservice {
    @Autowired
    private OrgnationMapper orgnationMapper;
    @Override
    public ResultModel save(Orgnation orgnation) {
        if (null == orgnation.getOrgName() || null == orgnation.getOrgPhone()||
        null == orgnation.getOrgPassword() || null == orgnation.getOrgMail()){
            return ResultModel.error(ResultStatus.DATA_NOT_NULL);
        }
        this.orgnationMapper.insert(orgnation);
        return ResultModel.ok(orgnation);
    }
}
