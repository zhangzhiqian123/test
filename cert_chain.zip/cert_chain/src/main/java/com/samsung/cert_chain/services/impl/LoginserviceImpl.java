package com.samsung.cert_chain.services.impl;

import com.samsung.cert_chain.mapper.AppUserMapper;
import com.samsung.cert_chain.mapper.OrgnationMapper;
import com.samsung.cert_chain.model.AppUser;
import com.samsung.cert_chain.model.AppUserExample;
import com.samsung.cert_chain.model.Orgnation;
import com.samsung.cert_chain.model.OrgnationExample;
import com.samsung.cert_chain.services.Loginservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LoginserviceImpl  implements Loginservice {
    @Autowired
    private OrgnationMapper orgnationMapper;

    @Autowired
    private AppUserMapper appUserMapper;
    @Override
    public AppUser selectUserById(int userId) {
        AppUser appUser = this.appUserMapper.selectByPrimaryKey(userId);

        return appUser;
    }

    @Override
    public Orgnation selectByOrgName(String orgname) {
        OrgnationExample orgnationExample = new OrgnationExample();
        OrgnationExample.Criteria criteria = orgnationExample.createCriteria();
        criteria.andOrgNameEqualTo(orgname);
        List<Orgnation> orgnations = this.orgnationMapper.selectByExample(orgnationExample);
        Orgnation orgnation;
        try{
            orgnation = orgnations.get(0);
        }catch (Exception e){
            orgnation = null;
        }
        return orgnation;
    }

    @Override
    public AppUser selectByUserName(String username) {
        AppUserExample appUserExample = new AppUserExample();
        AppUserExample.Criteria criteria = appUserExample.createCriteria();
        criteria.andUserNameEqualTo(username);
        List<AppUser> users = this.appUserMapper.selectByExample(appUserExample);

        AppUser appUseruser;
        try {
            appUseruser = users.get(0);
        } catch (Exception e) {
            return null;
        }
        return appUseruser;
    }

    @Override
    public Orgnation getOrg(String org_name) {

        Orgnation orgnation = this.orgnationMapper.getOrg(org_name);
        return orgnation;
    }
}
