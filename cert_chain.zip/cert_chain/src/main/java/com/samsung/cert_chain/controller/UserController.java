package com.samsung.cert_chain.controller;


import com.samsung.cert_chain.config.ResultStatus;
import com.samsung.cert_chain.model.AppUser;
import com.samsung.cert_chain.model.ResultModel;
import com.samsung.cert_chain.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class UserController {

    @Autowired
    private UserService userService;
    @RequestMapping(value = "/user/getalluser",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> getAllUser(Integer page, Integer rows, Integer org_id){
        if(null != page || null != rows || null != org_id) {
            List<AppUser> appUserList = this.userService.getAllUser(page, rows, org_id);

            return new ResponseEntity<ResultModel>(ResultModel.ok(appUserList), HttpStatus.OK);
        }else {
            return  new ResponseEntity<>(ResultModel.error(ResultStatus.GOOD_NOT_FOUND),HttpStatus.NOT_FOUND);
        }
    }

    @RequestMapping(value = "user/AddUser",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> AddCourse(Integer org_id, String user_name, String user_phone,
                                                 String user_job, String user_email){

        AppUser appUser = new AppUser();
        appUser.setOrgId(org_id);
        appUser.setUserName(user_name);
        appUser.setUserPhone(user_phone);
        appUser.setUserJob(user_job);
        appUser.setUserEmail(user_email);
        ResultModel resultModel = this.userService.SaveUser(appUser);
        if (resultModel.getCode() == -1005 || resultModel.getCode()==-1004 ){
            return new ResponseEntity<ResultModel>(resultModel,HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<ResultModel>(resultModel,HttpStatus.OK);
    }
    @RequestMapping(value = "user/deleteUser",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> deleteUser(Integer userId) {
        ResultModel resultModel = this.userService.deleteUser(userId);

        if (resultModel.getCode() == -1002) {
            return new ResponseEntity<>(resultModel, HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<ResultModel>(resultModel, HttpStatus.OK);
    }
}
