package com.samsung.cert_chain.model;

import java.util.Date;

public class CertiFication {
    private Integer certId;

    private String certName;

    private Integer orgId;

    private Integer certNumber;

    private Date certTime;

    private String certImage;

    public Integer getCertId() {
        return certId;
    }

    public void setCertId(Integer certId) {
        this.certId = certId;
    }

    public String getCertName() {
        return certName;
    }

    public void setCertName(String certName) {
        this.certName = certName == null ? null : certName.trim();
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public Integer getCertNumber() {
        return certNumber;
    }

    public void setCertNumber(Integer certNumber) {
        this.certNumber = certNumber;
    }

    public Date getCertTime() {
        return certTime;
    }

    public void setCertTime(Date certTime) {
        this.certTime = certTime;
    }

    public String getCertImage() {
        return certImage;
    }

    public void setCertImage(String certImage) {
        this.certImage = certImage == null ? null : certImage.trim();
    }
}