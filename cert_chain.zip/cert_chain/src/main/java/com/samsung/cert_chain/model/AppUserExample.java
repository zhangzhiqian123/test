package com.samsung.cert_chain.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AppUserExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public AppUserExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andUserIdIsNull() {
            addCriterion("user_id is null");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNotNull() {
            addCriterion("user_id is not null");
            return (Criteria) this;
        }

        public Criteria andUserIdEqualTo(Integer value) {
            addCriterion("user_id =", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotEqualTo(Integer value) {
            addCriterion("user_id <>", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThan(Integer value) {
            addCriterion("user_id >", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("user_id >=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThan(Integer value) {
            addCriterion("user_id <", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThanOrEqualTo(Integer value) {
            addCriterion("user_id <=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdIn(List<Integer> values) {
            addCriterion("user_id in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotIn(List<Integer> values) {
            addCriterion("user_id not in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdBetween(Integer value1, Integer value2) {
            addCriterion("user_id between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotBetween(Integer value1, Integer value2) {
            addCriterion("user_id not between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserNameIsNull() {
            addCriterion("user_name is null");
            return (Criteria) this;
        }

        public Criteria andUserNameIsNotNull() {
            addCriterion("user_name is not null");
            return (Criteria) this;
        }

        public Criteria andUserNameEqualTo(String value) {
            addCriterion("user_name =", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotEqualTo(String value) {
            addCriterion("user_name <>", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameGreaterThan(String value) {
            addCriterion("user_name >", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameGreaterThanOrEqualTo(String value) {
            addCriterion("user_name >=", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLessThan(String value) {
            addCriterion("user_name <", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLessThanOrEqualTo(String value) {
            addCriterion("user_name <=", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLike(String value) {
            addCriterion("user_name like", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotLike(String value) {
            addCriterion("user_name not like", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameIn(List<String> values) {
            addCriterion("user_name in", values, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotIn(List<String> values) {
            addCriterion("user_name not in", values, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameBetween(String value1, String value2) {
            addCriterion("user_name between", value1, value2, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotBetween(String value1, String value2) {
            addCriterion("user_name not between", value1, value2, "userName");
            return (Criteria) this;
        }

        public Criteria andUserPasswordIsNull() {
            addCriterion("user_password is null");
            return (Criteria) this;
        }

        public Criteria andUserPasswordIsNotNull() {
            addCriterion("user_password is not null");
            return (Criteria) this;
        }

        public Criteria andUserPasswordEqualTo(String value) {
            addCriterion("user_password =", value, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPasswordNotEqualTo(String value) {
            addCriterion("user_password <>", value, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPasswordGreaterThan(String value) {
            addCriterion("user_password >", value, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPasswordGreaterThanOrEqualTo(String value) {
            addCriterion("user_password >=", value, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPasswordLessThan(String value) {
            addCriterion("user_password <", value, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPasswordLessThanOrEqualTo(String value) {
            addCriterion("user_password <=", value, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPasswordLike(String value) {
            addCriterion("user_password like", value, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPasswordNotLike(String value) {
            addCriterion("user_password not like", value, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPasswordIn(List<String> values) {
            addCriterion("user_password in", values, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPasswordNotIn(List<String> values) {
            addCriterion("user_password not in", values, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPasswordBetween(String value1, String value2) {
            addCriterion("user_password between", value1, value2, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPasswordNotBetween(String value1, String value2) {
            addCriterion("user_password not between", value1, value2, "userPassword");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIsNull() {
            addCriterion("user_phone is null");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIsNotNull() {
            addCriterion("user_phone is not null");
            return (Criteria) this;
        }

        public Criteria andUserPhoneEqualTo(String value) {
            addCriterion("user_phone =", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotEqualTo(String value) {
            addCriterion("user_phone <>", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneGreaterThan(String value) {
            addCriterion("user_phone >", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("user_phone >=", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLessThan(String value) {
            addCriterion("user_phone <", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLessThanOrEqualTo(String value) {
            addCriterion("user_phone <=", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLike(String value) {
            addCriterion("user_phone like", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotLike(String value) {
            addCriterion("user_phone not like", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIn(List<String> values) {
            addCriterion("user_phone in", values, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotIn(List<String> values) {
            addCriterion("user_phone not in", values, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneBetween(String value1, String value2) {
            addCriterion("user_phone between", value1, value2, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotBetween(String value1, String value2) {
            addCriterion("user_phone not between", value1, value2, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageIsNull() {
            addCriterion("user_headimage is null");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageIsNotNull() {
            addCriterion("user_headimage is not null");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageEqualTo(String value) {
            addCriterion("user_headimage =", value, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageNotEqualTo(String value) {
            addCriterion("user_headimage <>", value, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageGreaterThan(String value) {
            addCriterion("user_headimage >", value, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageGreaterThanOrEqualTo(String value) {
            addCriterion("user_headimage >=", value, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageLessThan(String value) {
            addCriterion("user_headimage <", value, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageLessThanOrEqualTo(String value) {
            addCriterion("user_headimage <=", value, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageLike(String value) {
            addCriterion("user_headimage like", value, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageNotLike(String value) {
            addCriterion("user_headimage not like", value, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageIn(List<String> values) {
            addCriterion("user_headimage in", values, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageNotIn(List<String> values) {
            addCriterion("user_headimage not in", values, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageBetween(String value1, String value2) {
            addCriterion("user_headimage between", value1, value2, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserHeadimageNotBetween(String value1, String value2) {
            addCriterion("user_headimage not between", value1, value2, "userHeadimage");
            return (Criteria) this;
        }

        public Criteria andUserEmailIsNull() {
            addCriterion("user_email is null");
            return (Criteria) this;
        }

        public Criteria andUserEmailIsNotNull() {
            addCriterion("user_email is not null");
            return (Criteria) this;
        }

        public Criteria andUserEmailEqualTo(String value) {
            addCriterion("user_email =", value, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserEmailNotEqualTo(String value) {
            addCriterion("user_email <>", value, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserEmailGreaterThan(String value) {
            addCriterion("user_email >", value, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserEmailGreaterThanOrEqualTo(String value) {
            addCriterion("user_email >=", value, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserEmailLessThan(String value) {
            addCriterion("user_email <", value, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserEmailLessThanOrEqualTo(String value) {
            addCriterion("user_email <=", value, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserEmailLike(String value) {
            addCriterion("user_email like", value, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserEmailNotLike(String value) {
            addCriterion("user_email not like", value, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserEmailIn(List<String> values) {
            addCriterion("user_email in", values, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserEmailNotIn(List<String> values) {
            addCriterion("user_email not in", values, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserEmailBetween(String value1, String value2) {
            addCriterion("user_email between", value1, value2, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserEmailNotBetween(String value1, String value2) {
            addCriterion("user_email not between", value1, value2, "userEmail");
            return (Criteria) this;
        }

        public Criteria andUserSignIsNull() {
            addCriterion("user_sign is null");
            return (Criteria) this;
        }

        public Criteria andUserSignIsNotNull() {
            addCriterion("user_sign is not null");
            return (Criteria) this;
        }

        public Criteria andUserSignEqualTo(String value) {
            addCriterion("user_sign =", value, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserSignNotEqualTo(String value) {
            addCriterion("user_sign <>", value, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserSignGreaterThan(String value) {
            addCriterion("user_sign >", value, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserSignGreaterThanOrEqualTo(String value) {
            addCriterion("user_sign >=", value, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserSignLessThan(String value) {
            addCriterion("user_sign <", value, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserSignLessThanOrEqualTo(String value) {
            addCriterion("user_sign <=", value, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserSignLike(String value) {
            addCriterion("user_sign like", value, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserSignNotLike(String value) {
            addCriterion("user_sign not like", value, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserSignIn(List<String> values) {
            addCriterion("user_sign in", values, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserSignNotIn(List<String> values) {
            addCriterion("user_sign not in", values, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserSignBetween(String value1, String value2) {
            addCriterion("user_sign between", value1, value2, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserSignNotBetween(String value1, String value2) {
            addCriterion("user_sign not between", value1, value2, "userSign");
            return (Criteria) this;
        }

        public Criteria andUserJobIsNull() {
            addCriterion("user_job is null");
            return (Criteria) this;
        }

        public Criteria andUserJobIsNotNull() {
            addCriterion("user_job is not null");
            return (Criteria) this;
        }

        public Criteria andUserJobEqualTo(String value) {
            addCriterion("user_job =", value, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserJobNotEqualTo(String value) {
            addCriterion("user_job <>", value, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserJobGreaterThan(String value) {
            addCriterion("user_job >", value, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserJobGreaterThanOrEqualTo(String value) {
            addCriterion("user_job >=", value, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserJobLessThan(String value) {
            addCriterion("user_job <", value, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserJobLessThanOrEqualTo(String value) {
            addCriterion("user_job <=", value, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserJobLike(String value) {
            addCriterion("user_job like", value, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserJobNotLike(String value) {
            addCriterion("user_job not like", value, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserJobIn(List<String> values) {
            addCriterion("user_job in", values, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserJobNotIn(List<String> values) {
            addCriterion("user_job not in", values, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserJobBetween(String value1, String value2) {
            addCriterion("user_job between", value1, value2, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserJobNotBetween(String value1, String value2) {
            addCriterion("user_job not between", value1, value2, "userJob");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeIsNull() {
            addCriterion("user_signin_time is null");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeIsNotNull() {
            addCriterion("user_signin_time is not null");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeEqualTo(Date value) {
            addCriterion("user_signin_time =", value, "userSigninTime");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeNotEqualTo(Date value) {
            addCriterion("user_signin_time <>", value, "userSigninTime");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeGreaterThan(Date value) {
            addCriterion("user_signin_time >", value, "userSigninTime");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("user_signin_time >=", value, "userSigninTime");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeLessThan(Date value) {
            addCriterion("user_signin_time <", value, "userSigninTime");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeLessThanOrEqualTo(Date value) {
            addCriterion("user_signin_time <=", value, "userSigninTime");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeIn(List<Date> values) {
            addCriterion("user_signin_time in", values, "userSigninTime");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeNotIn(List<Date> values) {
            addCriterion("user_signin_time not in", values, "userSigninTime");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeBetween(Date value1, Date value2) {
            addCriterion("user_signin_time between", value1, value2, "userSigninTime");
            return (Criteria) this;
        }

        public Criteria andUserSigninTimeNotBetween(Date value1, Date value2) {
            addCriterion("user_signin_time not between", value1, value2, "userSigninTime");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesIsNull() {
            addCriterion("user_login_times is null");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesIsNotNull() {
            addCriterion("user_login_times is not null");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesEqualTo(Integer value) {
            addCriterion("user_login_times =", value, "userLoginTimes");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesNotEqualTo(Integer value) {
            addCriterion("user_login_times <>", value, "userLoginTimes");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesGreaterThan(Integer value) {
            addCriterion("user_login_times >", value, "userLoginTimes");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesGreaterThanOrEqualTo(Integer value) {
            addCriterion("user_login_times >=", value, "userLoginTimes");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesLessThan(Integer value) {
            addCriterion("user_login_times <", value, "userLoginTimes");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesLessThanOrEqualTo(Integer value) {
            addCriterion("user_login_times <=", value, "userLoginTimes");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesIn(List<Integer> values) {
            addCriterion("user_login_times in", values, "userLoginTimes");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesNotIn(List<Integer> values) {
            addCriterion("user_login_times not in", values, "userLoginTimes");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesBetween(Integer value1, Integer value2) {
            addCriterion("user_login_times between", value1, value2, "userLoginTimes");
            return (Criteria) this;
        }

        public Criteria andUserLoginTimesNotBetween(Integer value1, Integer value2) {
            addCriterion("user_login_times not between", value1, value2, "userLoginTimes");
            return (Criteria) this;
        }

        public Criteria andOrgIdIsNull() {
            addCriterion("org_id is null");
            return (Criteria) this;
        }

        public Criteria andOrgIdIsNotNull() {
            addCriterion("org_id is not null");
            return (Criteria) this;
        }

        public Criteria andOrgIdEqualTo(Integer value) {
            addCriterion("org_id =", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdNotEqualTo(Integer value) {
            addCriterion("org_id <>", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdGreaterThan(Integer value) {
            addCriterion("org_id >", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("org_id >=", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdLessThan(Integer value) {
            addCriterion("org_id <", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdLessThanOrEqualTo(Integer value) {
            addCriterion("org_id <=", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdIn(List<Integer> values) {
            addCriterion("org_id in", values, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdNotIn(List<Integer> values) {
            addCriterion("org_id not in", values, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdBetween(Integer value1, Integer value2) {
            addCriterion("org_id between", value1, value2, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdNotBetween(Integer value1, Integer value2) {
            addCriterion("org_id not between", value1, value2, "orgId");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityIsNull() {
            addCriterion("user_authority is null");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityIsNotNull() {
            addCriterion("user_authority is not null");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityEqualTo(Integer value) {
            addCriterion("user_authority =", value, "userAuthority");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityNotEqualTo(Integer value) {
            addCriterion("user_authority <>", value, "userAuthority");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityGreaterThan(Integer value) {
            addCriterion("user_authority >", value, "userAuthority");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityGreaterThanOrEqualTo(Integer value) {
            addCriterion("user_authority >=", value, "userAuthority");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityLessThan(Integer value) {
            addCriterion("user_authority <", value, "userAuthority");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityLessThanOrEqualTo(Integer value) {
            addCriterion("user_authority <=", value, "userAuthority");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityIn(List<Integer> values) {
            addCriterion("user_authority in", values, "userAuthority");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityNotIn(List<Integer> values) {
            addCriterion("user_authority not in", values, "userAuthority");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityBetween(Integer value1, Integer value2) {
            addCriterion("user_authority between", value1, value2, "userAuthority");
            return (Criteria) this;
        }

        public Criteria andUserAuthorityNotBetween(Integer value1, Integer value2) {
            addCriterion("user_authority not between", value1, value2, "userAuthority");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}