package com.samsung.cert_chain.mapper;

import com.samsung.cert_chain.model.Orgnation;
import com.samsung.cert_chain.model.OrgnationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OrgnationMapper {
    long countByExample(OrgnationExample example);

    int deleteByExample(OrgnationExample example);

    int deleteByPrimaryKey(Integer orgId);

    int insert(Orgnation record);

    int insertSelective(Orgnation record);

    List<Orgnation> selectByExample(OrgnationExample example);

    Orgnation selectByPrimaryKey(Integer orgId);

    int updateByExampleSelective(@Param("record") Orgnation record, @Param("example") OrgnationExample example);

    int updateByExample(@Param("record") Orgnation record, @Param("example") OrgnationExample example);

    int updateByPrimaryKeySelective(Orgnation record);

    int updateByPrimaryKey(Orgnation record);

    Orgnation getOrg(String org_name);
}