package com.samsung.cert_chain.services.impl;

import com.github.pagehelper.PageHelper;
import com.samsung.cert_chain.config.ResultStatus;
import com.samsung.cert_chain.mapper.AppUserMapper;
import com.samsung.cert_chain.model.AppUser;
import com.samsung.cert_chain.model.AppUserExample;
import com.samsung.cert_chain.model.ResultModel;
import com.samsung.cert_chain.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private AppUserMapper appUserMapper;
    @Override
    public List<AppUser> getAllUser(Integer page, Integer rows,Integer org_id) {
        if (null != page && null != rows) {
            PageHelper.startPage(page, rows);
        }
        List<AppUser> list = this.appUserMapper.getAllByUser(org_id);
        return list;
    }

    @Override
    public ResultModel SaveUser(AppUser appUser) {

        if (null == appUser.getUserName() || null == appUser.getUserJob()
                ){
            return ResultModel.error(ResultStatus.DATA_NOT_NULL);
        }
        this.appUserMapper.insert(appUser);
        return ResultModel.ok();
    }

    @Override
    public ResultModel deleteUser(int userId) {
        AppUser appUser = this.appUserMapper.selectByPrimaryKey(userId);

        if (null == appUser) {
            return ResultModel.error(ResultStatus.USER_NOT_FOUND);
        }

        this.appUserMapper.deleteByPrimaryKey(userId);
        return ResultModel.ok();
    }
}
