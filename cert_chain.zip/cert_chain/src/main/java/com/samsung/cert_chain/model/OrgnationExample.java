package com.samsung.cert_chain.model;

import java.util.ArrayList;
import java.util.List;

public class OrgnationExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public OrgnationExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andOrgIdIsNull() {
            addCriterion("org_id is null");
            return (Criteria) this;
        }

        public Criteria andOrgIdIsNotNull() {
            addCriterion("org_id is not null");
            return (Criteria) this;
        }

        public Criteria andOrgIdEqualTo(Integer value) {
            addCriterion("org_id =", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdNotEqualTo(Integer value) {
            addCriterion("org_id <>", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdGreaterThan(Integer value) {
            addCriterion("org_id >", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("org_id >=", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdLessThan(Integer value) {
            addCriterion("org_id <", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdLessThanOrEqualTo(Integer value) {
            addCriterion("org_id <=", value, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdIn(List<Integer> values) {
            addCriterion("org_id in", values, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdNotIn(List<Integer> values) {
            addCriterion("org_id not in", values, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdBetween(Integer value1, Integer value2) {
            addCriterion("org_id between", value1, value2, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgIdNotBetween(Integer value1, Integer value2) {
            addCriterion("org_id not between", value1, value2, "orgId");
            return (Criteria) this;
        }

        public Criteria andOrgNameIsNull() {
            addCriterion("org_name is null");
            return (Criteria) this;
        }

        public Criteria andOrgNameIsNotNull() {
            addCriterion("org_name is not null");
            return (Criteria) this;
        }

        public Criteria andOrgNameEqualTo(String value) {
            addCriterion("org_name =", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameNotEqualTo(String value) {
            addCriterion("org_name <>", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameGreaterThan(String value) {
            addCriterion("org_name >", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameGreaterThanOrEqualTo(String value) {
            addCriterion("org_name >=", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameLessThan(String value) {
            addCriterion("org_name <", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameLessThanOrEqualTo(String value) {
            addCriterion("org_name <=", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameLike(String value) {
            addCriterion("org_name like", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameNotLike(String value) {
            addCriterion("org_name not like", value, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameIn(List<String> values) {
            addCriterion("org_name in", values, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameNotIn(List<String> values) {
            addCriterion("org_name not in", values, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameBetween(String value1, String value2) {
            addCriterion("org_name between", value1, value2, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgNameNotBetween(String value1, String value2) {
            addCriterion("org_name not between", value1, value2, "orgName");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordIsNull() {
            addCriterion("org_password is null");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordIsNotNull() {
            addCriterion("org_password is not null");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordEqualTo(String value) {
            addCriterion("org_password =", value, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordNotEqualTo(String value) {
            addCriterion("org_password <>", value, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordGreaterThan(String value) {
            addCriterion("org_password >", value, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordGreaterThanOrEqualTo(String value) {
            addCriterion("org_password >=", value, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordLessThan(String value) {
            addCriterion("org_password <", value, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordLessThanOrEqualTo(String value) {
            addCriterion("org_password <=", value, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordLike(String value) {
            addCriterion("org_password like", value, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordNotLike(String value) {
            addCriterion("org_password not like", value, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordIn(List<String> values) {
            addCriterion("org_password in", values, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordNotIn(List<String> values) {
            addCriterion("org_password not in", values, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordBetween(String value1, String value2) {
            addCriterion("org_password between", value1, value2, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgPasswordNotBetween(String value1, String value2) {
            addCriterion("org_password not between", value1, value2, "orgPassword");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerIsNull() {
            addCriterion("org_owner is null");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerIsNotNull() {
            addCriterion("org_owner is not null");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerEqualTo(String value) {
            addCriterion("org_owner =", value, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerNotEqualTo(String value) {
            addCriterion("org_owner <>", value, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerGreaterThan(String value) {
            addCriterion("org_owner >", value, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerGreaterThanOrEqualTo(String value) {
            addCriterion("org_owner >=", value, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerLessThan(String value) {
            addCriterion("org_owner <", value, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerLessThanOrEqualTo(String value) {
            addCriterion("org_owner <=", value, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerLike(String value) {
            addCriterion("org_owner like", value, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerNotLike(String value) {
            addCriterion("org_owner not like", value, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerIn(List<String> values) {
            addCriterion("org_owner in", values, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerNotIn(List<String> values) {
            addCriterion("org_owner not in", values, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerBetween(String value1, String value2) {
            addCriterion("org_owner between", value1, value2, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgOwnerNotBetween(String value1, String value2) {
            addCriterion("org_owner not between", value1, value2, "orgOwner");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageIsNull() {
            addCriterion("org_headimage is null");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageIsNotNull() {
            addCriterion("org_headimage is not null");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageEqualTo(String value) {
            addCriterion("org_headimage =", value, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageNotEqualTo(String value) {
            addCriterion("org_headimage <>", value, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageGreaterThan(String value) {
            addCriterion("org_headimage >", value, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageGreaterThanOrEqualTo(String value) {
            addCriterion("org_headimage >=", value, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageLessThan(String value) {
            addCriterion("org_headimage <", value, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageLessThanOrEqualTo(String value) {
            addCriterion("org_headimage <=", value, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageLike(String value) {
            addCriterion("org_headimage like", value, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageNotLike(String value) {
            addCriterion("org_headimage not like", value, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageIn(List<String> values) {
            addCriterion("org_headimage in", values, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageNotIn(List<String> values) {
            addCriterion("org_headimage not in", values, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageBetween(String value1, String value2) {
            addCriterion("org_headimage between", value1, value2, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgHeadimageNotBetween(String value1, String value2) {
            addCriterion("org_headimage not between", value1, value2, "orgHeadimage");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneIsNull() {
            addCriterion("org_phone is null");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneIsNotNull() {
            addCriterion("org_phone is not null");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneEqualTo(String value) {
            addCriterion("org_phone =", value, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneNotEqualTo(String value) {
            addCriterion("org_phone <>", value, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneGreaterThan(String value) {
            addCriterion("org_phone >", value, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("org_phone >=", value, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneLessThan(String value) {
            addCriterion("org_phone <", value, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneLessThanOrEqualTo(String value) {
            addCriterion("org_phone <=", value, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneLike(String value) {
            addCriterion("org_phone like", value, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneNotLike(String value) {
            addCriterion("org_phone not like", value, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneIn(List<String> values) {
            addCriterion("org_phone in", values, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneNotIn(List<String> values) {
            addCriterion("org_phone not in", values, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneBetween(String value1, String value2) {
            addCriterion("org_phone between", value1, value2, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgPhoneNotBetween(String value1, String value2) {
            addCriterion("org_phone not between", value1, value2, "orgPhone");
            return (Criteria) this;
        }

        public Criteria andOrgMailIsNull() {
            addCriterion("org_mail is null");
            return (Criteria) this;
        }

        public Criteria andOrgMailIsNotNull() {
            addCriterion("org_mail is not null");
            return (Criteria) this;
        }

        public Criteria andOrgMailEqualTo(String value) {
            addCriterion("org_mail =", value, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgMailNotEqualTo(String value) {
            addCriterion("org_mail <>", value, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgMailGreaterThan(String value) {
            addCriterion("org_mail >", value, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgMailGreaterThanOrEqualTo(String value) {
            addCriterion("org_mail >=", value, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgMailLessThan(String value) {
            addCriterion("org_mail <", value, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgMailLessThanOrEqualTo(String value) {
            addCriterion("org_mail <=", value, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgMailLike(String value) {
            addCriterion("org_mail like", value, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgMailNotLike(String value) {
            addCriterion("org_mail not like", value, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgMailIn(List<String> values) {
            addCriterion("org_mail in", values, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgMailNotIn(List<String> values) {
            addCriterion("org_mail not in", values, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgMailBetween(String value1, String value2) {
            addCriterion("org_mail between", value1, value2, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgMailNotBetween(String value1, String value2) {
            addCriterion("org_mail not between", value1, value2, "orgMail");
            return (Criteria) this;
        }

        public Criteria andOrgAddressIsNull() {
            addCriterion("org_address is null");
            return (Criteria) this;
        }

        public Criteria andOrgAddressIsNotNull() {
            addCriterion("org_address is not null");
            return (Criteria) this;
        }

        public Criteria andOrgAddressEqualTo(String value) {
            addCriterion("org_address =", value, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgAddressNotEqualTo(String value) {
            addCriterion("org_address <>", value, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgAddressGreaterThan(String value) {
            addCriterion("org_address >", value, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgAddressGreaterThanOrEqualTo(String value) {
            addCriterion("org_address >=", value, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgAddressLessThan(String value) {
            addCriterion("org_address <", value, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgAddressLessThanOrEqualTo(String value) {
            addCriterion("org_address <=", value, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgAddressLike(String value) {
            addCriterion("org_address like", value, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgAddressNotLike(String value) {
            addCriterion("org_address not like", value, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgAddressIn(List<String> values) {
            addCriterion("org_address in", values, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgAddressNotIn(List<String> values) {
            addCriterion("org_address not in", values, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgAddressBetween(String value1, String value2) {
            addCriterion("org_address between", value1, value2, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgAddressNotBetween(String value1, String value2) {
            addCriterion("org_address not between", value1, value2, "orgAddress");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseIsNull() {
            addCriterion("org_license is null");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseIsNotNull() {
            addCriterion("org_license is not null");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseEqualTo(String value) {
            addCriterion("org_license =", value, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseNotEqualTo(String value) {
            addCriterion("org_license <>", value, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseGreaterThan(String value) {
            addCriterion("org_license >", value, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseGreaterThanOrEqualTo(String value) {
            addCriterion("org_license >=", value, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseLessThan(String value) {
            addCriterion("org_license <", value, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseLessThanOrEqualTo(String value) {
            addCriterion("org_license <=", value, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseLike(String value) {
            addCriterion("org_license like", value, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseNotLike(String value) {
            addCriterion("org_license not like", value, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseIn(List<String> values) {
            addCriterion("org_license in", values, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseNotIn(List<String> values) {
            addCriterion("org_license not in", values, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseBetween(String value1, String value2) {
            addCriterion("org_license between", value1, value2, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicenseNotBetween(String value1, String value2) {
            addCriterion("org_license not between", value1, value2, "orgLicense");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoIsNull() {
            addCriterion("org_licenseno is null");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoIsNotNull() {
            addCriterion("org_licenseno is not null");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoEqualTo(String value) {
            addCriterion("org_licenseno =", value, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoNotEqualTo(String value) {
            addCriterion("org_licenseno <>", value, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoGreaterThan(String value) {
            addCriterion("org_licenseno >", value, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoGreaterThanOrEqualTo(String value) {
            addCriterion("org_licenseno >=", value, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoLessThan(String value) {
            addCriterion("org_licenseno <", value, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoLessThanOrEqualTo(String value) {
            addCriterion("org_licenseno <=", value, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoLike(String value) {
            addCriterion("org_licenseno like", value, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoNotLike(String value) {
            addCriterion("org_licenseno not like", value, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoIn(List<String> values) {
            addCriterion("org_licenseno in", values, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoNotIn(List<String> values) {
            addCriterion("org_licenseno not in", values, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoBetween(String value1, String value2) {
            addCriterion("org_licenseno between", value1, value2, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgLicensenoNotBetween(String value1, String value2) {
            addCriterion("org_licenseno not between", value1, value2, "orgLicenseno");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardIsNull() {
            addCriterion("org_ownerIdcard is null");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardIsNotNull() {
            addCriterion("org_ownerIdcard is not null");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardEqualTo(String value) {
            addCriterion("org_ownerIdcard =", value, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardNotEqualTo(String value) {
            addCriterion("org_ownerIdcard <>", value, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardGreaterThan(String value) {
            addCriterion("org_ownerIdcard >", value, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardGreaterThanOrEqualTo(String value) {
            addCriterion("org_ownerIdcard >=", value, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardLessThan(String value) {
            addCriterion("org_ownerIdcard <", value, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardLessThanOrEqualTo(String value) {
            addCriterion("org_ownerIdcard <=", value, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardLike(String value) {
            addCriterion("org_ownerIdcard like", value, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardNotLike(String value) {
            addCriterion("org_ownerIdcard not like", value, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardIn(List<String> values) {
            addCriterion("org_ownerIdcard in", values, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardNotIn(List<String> values) {
            addCriterion("org_ownerIdcard not in", values, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardBetween(String value1, String value2) {
            addCriterion("org_ownerIdcard between", value1, value2, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardNotBetween(String value1, String value2) {
            addCriterion("org_ownerIdcard not between", value1, value2, "orgOwneridcard");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseIsNull() {
            addCriterion("org_ownerIdcardreverse is null");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseIsNotNull() {
            addCriterion("org_ownerIdcardreverse is not null");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseEqualTo(String value) {
            addCriterion("org_ownerIdcardreverse =", value, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseNotEqualTo(String value) {
            addCriterion("org_ownerIdcardreverse <>", value, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseGreaterThan(String value) {
            addCriterion("org_ownerIdcardreverse >", value, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseGreaterThanOrEqualTo(String value) {
            addCriterion("org_ownerIdcardreverse >=", value, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseLessThan(String value) {
            addCriterion("org_ownerIdcardreverse <", value, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseLessThanOrEqualTo(String value) {
            addCriterion("org_ownerIdcardreverse <=", value, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseLike(String value) {
            addCriterion("org_ownerIdcardreverse like", value, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseNotLike(String value) {
            addCriterion("org_ownerIdcardreverse not like", value, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseIn(List<String> values) {
            addCriterion("org_ownerIdcardreverse in", values, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseNotIn(List<String> values) {
            addCriterion("org_ownerIdcardreverse not in", values, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseBetween(String value1, String value2) {
            addCriterion("org_ownerIdcardreverse between", value1, value2, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgOwneridcardreverseNotBetween(String value1, String value2) {
            addCriterion("org_ownerIdcardreverse not between", value1, value2, "orgOwneridcardreverse");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyIsNull() {
            addCriterion("org_privatekey is null");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyIsNotNull() {
            addCriterion("org_privatekey is not null");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyEqualTo(String value) {
            addCriterion("org_privatekey =", value, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyNotEqualTo(String value) {
            addCriterion("org_privatekey <>", value, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyGreaterThan(String value) {
            addCriterion("org_privatekey >", value, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyGreaterThanOrEqualTo(String value) {
            addCriterion("org_privatekey >=", value, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyLessThan(String value) {
            addCriterion("org_privatekey <", value, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyLessThanOrEqualTo(String value) {
            addCriterion("org_privatekey <=", value, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyLike(String value) {
            addCriterion("org_privatekey like", value, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyNotLike(String value) {
            addCriterion("org_privatekey not like", value, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyIn(List<String> values) {
            addCriterion("org_privatekey in", values, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyNotIn(List<String> values) {
            addCriterion("org_privatekey not in", values, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyBetween(String value1, String value2) {
            addCriterion("org_privatekey between", value1, value2, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgPrivatekeyNotBetween(String value1, String value2) {
            addCriterion("org_privatekey not between", value1, value2, "orgPrivatekey");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityIsNull() {
            addCriterion("org_authority is null");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityIsNotNull() {
            addCriterion("org_authority is not null");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityEqualTo(Integer value) {
            addCriterion("org_authority =", value, "orgAuthority");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityNotEqualTo(Integer value) {
            addCriterion("org_authority <>", value, "orgAuthority");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityGreaterThan(Integer value) {
            addCriterion("org_authority >", value, "orgAuthority");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityGreaterThanOrEqualTo(Integer value) {
            addCriterion("org_authority >=", value, "orgAuthority");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityLessThan(Integer value) {
            addCriterion("org_authority <", value, "orgAuthority");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityLessThanOrEqualTo(Integer value) {
            addCriterion("org_authority <=", value, "orgAuthority");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityIn(List<Integer> values) {
            addCriterion("org_authority in", values, "orgAuthority");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityNotIn(List<Integer> values) {
            addCriterion("org_authority not in", values, "orgAuthority");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityBetween(Integer value1, Integer value2) {
            addCriterion("org_authority between", value1, value2, "orgAuthority");
            return (Criteria) this;
        }

        public Criteria andOrgAuthorityNotBetween(Integer value1, Integer value2) {
            addCriterion("org_authority not between", value1, value2, "orgAuthority");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}