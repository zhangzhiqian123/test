package com.samsung.cert_chain.services;

import com.samsung.cert_chain.model.Orgnation;
import com.samsung.cert_chain.model.ResultModel;

public interface Registerservice {
    ResultModel save(Orgnation orgnation);
}
