package com.samsung.cert_chain.services.impl;

import com.github.pagehelper.PageHelper;
import com.samsung.cert_chain.config.ResultStatus;
import com.samsung.cert_chain.mapper.Cert_UserMapper;
import com.samsung.cert_chain.mapper.CertiFicationMapper;
import com.samsung.cert_chain.model.Cert_User;
import com.samsung.cert_chain.model.Cert_UserExample;
import com.samsung.cert_chain.model.CertiFication;
import com.samsung.cert_chain.model.ResultModel;
import com.samsung.cert_chain.services.CertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CertServiceImpl implements CertService {
    @Autowired
    private CertiFicationMapper certiFicationMapper;
    @Autowired
    private Cert_UserMapper cert_userMapper;
    @Override
    public ResultModel save(CertiFication certiFication) {
        if (null == certiFication.getCertName() ){
            return ResultModel.error(ResultStatus.DATA_NOT_NULL);
        }
        this.certiFicationMapper.insert(certiFication);
        return ResultModel.ok();
    }

    @Override
    public List<Cert_User> getAppCert(Integer id) {
        Cert_UserExample cert_userExample = new Cert_UserExample();
        Cert_UserExample.Criteria criteria = cert_userExample.createCriteria();
        List<Cert_User> list = this.cert_userMapper.getAppCert(id);
        return list;
    }

    @Override
    public List<CertiFication> getAllCert(Integer page, Integer rows, Integer org_id) {
        if (null != page && null != rows) {
            PageHelper.startPage(page, rows);
        }
        List<CertiFication> list = this.certiFicationMapper.getAllByCert(org_id);
        return list;
    }


}
