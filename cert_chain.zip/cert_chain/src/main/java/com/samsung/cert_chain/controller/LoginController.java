package com.samsung.cert_chain.controller;


import com.samsung.cert_chain.config.ResultStatus;
import com.samsung.cert_chain.model.AppUser;
import com.samsung.cert_chain.model.Orgnation;
import com.samsung.cert_chain.model.ResultModel;
import com.samsung.cert_chain.services.Loginservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class LoginController {
    @Autowired
    private Loginservice loginservice;

    @RequestMapping(value = "/orglogin",method = RequestMethod.POST)
  //  public ResponseEntity<ResultModel> login(@RequestParam(value = "userName", required = true) String userName,
     //                                        @RequestParam(value = "passWord", required = true) String passWord) {
        public ResponseEntity<ResultModel> login(@RequestParam(value = "userName", required = false) String userName,
                @RequestParam(value = "passWord", required = false) String passWord) {
        System.out.println(userName);
        System.out.println(passWord);
        if (null == userName || null == passWord) {
            return new ResponseEntity<ResultModel>(ResultModel.error(ResultStatus.DATA_NOT_NULL), HttpStatus.BAD_REQUEST);
        }
        Orgnation orgnation = this.loginservice.selectByOrgName(userName);

        if (null == orgnation || // 未注册
                !orgnation.getOrgPassword().equals(passWord)) { //密码错误
            // 提示用户名或者密码错误
            return new ResponseEntity<>(ResultModel.error(ResultStatus.USERNAME_OR_PASSWORD_ERROR), HttpStatus.NOT_FOUND);
        }
        // 生成一个token，保存用户登录状态
        Orgnation  orgnationList = this.loginservice.getOrg(userName);
        return new ResponseEntity<>(ResultModel.ok(orgnationList), HttpStatus.OK);
    }
    @RequestMapping(value = "/app/login",method = RequestMethod.POST)
    public ResponseEntity<ResultModel> applogin(String userName,String passWord){
        if (null == userName || null == passWord){
            return new ResponseEntity<ResultModel>(ResultModel.error(ResultStatus.DATA_NOT_NULL),HttpStatus.NOT_FOUND);

        }
        AppUser appUser = this.loginservice.selectByUserName(userName);
        if (appUser == null){
            return new ResponseEntity<ResultModel>(ResultModel.error(ResultStatus.USER_NOT_FOUND),HttpStatus.NOT_FOUND);
        }else if (!appUser.getUserPassword().equals(passWord)){
            return new ResponseEntity<ResultModel>(ResultModel.error(ResultStatus.USERNAME_OR_PASSWORD_ERROR),HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(ResultModel.ok(ResultStatus.SUCCESS),HttpStatus.OK);
    }
}
