package com.samsung.cert_chain.services;

import com.samsung.cert_chain.model.Cert_User;
import com.samsung.cert_chain.model.CertiFication;
import com.samsung.cert_chain.model.ResultModel;

import java.util.List;

public interface CertService {

    List<CertiFication> getAllCert(Integer page, Integer rows, Integer org_id);

    ResultModel save(CertiFication certiFication);
    List<Cert_User> getAppCert(Integer id);
}
