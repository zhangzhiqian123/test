package com.samsung.cert_chain.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Orgnation {
    private Integer orgId;

    private String orgName;

    private String orgPassword;

    private String orgOwner;

    private String orgHeadimage;

    private String orgPhone;

    private String orgMail;

    private String orgAddress;

    private String orgLicense;

    private String orgLicenseno;

    private String orgOwneridcard;

    private String orgOwneridcardreverse;

    private String orgPrivatekey;

    private Integer orgAuthority;

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName == null ? null : orgName.trim();
    }

    public String getOrgPassword() {
        return orgPassword;
    }

    public void setOrgPassword(String orgPassword) {
        this.orgPassword = orgPassword == null ? null : orgPassword.trim();
    }

    public String getOrgOwner() {
        return orgOwner;
    }

    public void setOrgOwner(String orgOwner) {
        this.orgOwner = orgOwner == null ? null : orgOwner.trim();
    }

    public String getOrgHeadimage() {
        return orgHeadimage;
    }

    public void setOrgHeadimage(String orgHeadimage) {
        this.orgHeadimage = orgHeadimage == null ? null : orgHeadimage.trim();
    }

    public String getOrgPhone() {
        return orgPhone;
    }

    public void setOrgPhone(String orgPhone) {
        this.orgPhone = orgPhone == null ? null : orgPhone.trim();
    }

    public String getOrgMail() {
        return orgMail;
    }

    public void setOrgMail(String orgMail) {
        this.orgMail = orgMail == null ? null : orgMail.trim();
    }

    public String getOrgAddress() {
        return orgAddress;
    }

    public void setOrgAddress(String orgAddress) {
        this.orgAddress = orgAddress == null ? null : orgAddress.trim();
    }

    public String getOrgLicense() {
        return orgLicense;
    }

    public void setOrgLicense(String orgLicense) {
        this.orgLicense = orgLicense == null ? null : orgLicense.trim();
    }

    public String getOrgLicenseno() {
        return orgLicenseno;
    }

    public void setOrgLicenseno(String orgLicenseno) {
        this.orgLicenseno = orgLicenseno == null ? null : orgLicenseno.trim();
    }

    public String getOrgOwneridcard() {
        return orgOwneridcard;
    }

    public void setOrgOwneridcard(String orgOwneridcard) {
        this.orgOwneridcard = orgOwneridcard == null ? null : orgOwneridcard.trim();
    }

    public String getOrgOwneridcardreverse() {
        return orgOwneridcardreverse;
    }

    public void setOrgOwneridcardreverse(String orgOwneridcardreverse) {
        this.orgOwneridcardreverse = orgOwneridcardreverse == null ? null : orgOwneridcardreverse.trim();
    }

    public String getOrgPrivatekey() {
        return orgPrivatekey;
    }

    public void setOrgPrivatekey(String orgPrivatekey) {
        this.orgPrivatekey = orgPrivatekey == null ? null : orgPrivatekey.trim();
    }

    public Integer getOrgAuthority() {
        return orgAuthority;
    }

    public void setOrgAuthority(Integer orgAuthority) {
        this.orgAuthority = orgAuthority;
    }
}