package com.samsung.cert_chain.mapper;

import com.samsung.cert_chain.model.Cert_User;
import com.samsung.cert_chain.model.Cert_UserExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface Cert_UserMapper {
    long countByExample(Cert_UserExample example);

    int deleteByExample(Cert_UserExample example);

    int insert(Cert_User record);

    int insertSelective(Cert_User record);

    List<Cert_User> selectByExample(Cert_UserExample example);

    int updateByExampleSelective(@Param("record") Cert_User record, @Param("example") Cert_UserExample example);

    int updateByExample(@Param("record") Cert_User record, @Param("example") Cert_UserExample example);
    List<Cert_User> getAppCert(Integer user_id);
}